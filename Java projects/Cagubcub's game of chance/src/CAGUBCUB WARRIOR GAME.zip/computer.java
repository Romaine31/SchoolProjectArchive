/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | TemplatesJOHN ROMAINE CAGUBCUB
 * and open the template in the editor.
 */
import java.util.Random;
/**
 *JOHN ROMAINE CAGUBCUB
 * @author Raine
 */
public class computer {
    public int cpu (){
        
    Random z = new Random ();
    int x = z.nextInt(3)+1;
    return x;
}
}//JOHN ROMAINE CAGUBCUB